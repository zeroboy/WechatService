token = "zeroboy"
robot_chat_time_len = 180
robot_key = [
                "bbacbddd2b2349519b579cc0ff63de6e",
                "4449945e5861479bab2d70bec3cb49bc",
                "6c23d076b87342d4807878a226e685f3"
            ]

